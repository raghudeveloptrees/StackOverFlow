function First_Q_Page_Tab() {
    gettingOpen = document.getElementsByClassName("First-Q_Page");
    gettingOpen[0].classList.add("active");


    gettingOpen = document.getElementsByClassName("Second-Q_Page");
    gettingOpen[0].classList.remove("active");


    gettingOpen = document.getElementsByClassName("Third-Q_Page");
    gettingOpen[0].classList.remove("active");


    gettingOpen = document.getElementsByClassName("Fourth-Q_Page");
    gettingOpen[0].classList.remove("active");

}


function Second_Q_Page_Tab() {
    gettingOpen = document.getElementsByClassName("Second-Q_Page");
    gettingOpen[0].classList.add("active");


    gettingOpen = document.getElementsByClassName("First-Q_Page");
    gettingOpen[0].classList.remove("active");


    gettingOpen = document.getElementsByClassName("Third-Q_Page");
    gettingOpen[0].classList.remove("active");


    gettingOpen = document.getElementsByClassName("Fourth-Q_Page");
    gettingOpen[0].classList.remove("active");

}


function Third_Q_Page_Tab() {
    gettingOpen = document.getElementsByClassName("Third-Q_Page");
    gettingOpen[0].classList.add("active");


    gettingOpen = document.getElementsByClassName("Second-Q_Page");
    gettingOpen[0].classList.remove("active");


    gettingOpen = document.getElementsByClassName("First-Q_Page");
    gettingOpen[0].classList.remove("active");


    gettingOpen = document.getElementsByClassName("Fourth-Q_Page");
    gettingOpen[0].classList.remove("active");

}


function Fourth_Q_Page_Tab() {
    gettingOpen = document.getElementsByClassName("Fourth-Q_Page");
    gettingOpen[0].classList.add("active");


    gettingOpen = document.getElementsByClassName("First-Q_Page");
    gettingOpen[0].classList.remove("active");


    gettingOpen = document.getElementsByClassName("Second-Q_Page");
    gettingOpen[0].classList.remove("active");


    gettingOpen = document.getElementsByClassName("Third-Q_Page");
    gettingOpen[0].classList.remove("active");

}